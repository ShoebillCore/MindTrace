(function(){"use strict";chrome.action.onClicked.addListener(e=>{e.id!=null&&chrome.tabs.sendMessage(e.id,{type:"OPEN_MINDTRACE"})})})();
